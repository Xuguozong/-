package com.work.mapper;

import com.work.model.Stock;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface StockMapper {
    @Select("select * from stock where id = #{id}")
    Stock findById(Integer id);
}
