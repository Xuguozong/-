package com.work.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.work.api.StockService;
import com.work.mapper.StockMapper;
import com.work.model.Stock;
import org.springframework.beans.factory.annotation.Autowired;

@Service(
        version = "${demo.service.version}",
        application = "${dubbo.application.id}",
        protocol = "${dubbo.protocol.id}",
        registry = "${dubbo.registry.id}"
)
public class StockServiceImpl implements StockService {

    @Autowired
    private StockMapper stockMapper;

    @Override
    public Stock findById(Integer id) {
        return this.stockMapper.findById(id);
    }
}
