package com.work.api;

public interface OrderService {
}
