package com.work.api;

import com.work.model.Stock;

public interface StockService {
    Stock findById(Integer id);
}
