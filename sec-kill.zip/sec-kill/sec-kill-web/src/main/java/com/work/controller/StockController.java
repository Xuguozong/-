package com.work.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.work.api.StockService;
import com.work.model.Stock;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sec-kill")
public class StockController {
    @Reference(version = "${demo.service.version}",
            application = "${dubbo.application.id}",
            url = "dubbo://localhost:12345")
    private StockService stockService;

    @GetMapping("/stock/{id}")
    public Stock find(@PathVariable("id") Integer id){
        return this.stockService.findById(id);
    }
}
